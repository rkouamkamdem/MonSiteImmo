window.mobilecheck = function() {
    var check = false;
    if (window.innerWidth < 768 || window.innerHeight < 525) {
        check = true;
    }
    return check;
};