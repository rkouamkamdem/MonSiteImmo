/*  ------------------------------------- CI DESSOUS RAJOUT DE MON JS POUR SE CONNECTER VIA ENCAPTO  ------------------------------   */

function deviceLogin(loginInfo, loginData, redirectUrl) {

    var successUrl = loginData.redirect_url || buildSuccessURL();

    //Si une Url de redirection est spécifiée, alors on effectue une redirection vers cette dernière
    if (redirectUrl !== '' ){
        successUrl = redirectUrl; //var successUrl = 'https://connect.adael.com/welcome/';
    }
    console.log('------ Mon Url de redirection est  ['+redirectUrl+'] ------------');
    switch (loginInfo.device_type) {

        case 'zd':
            window.location.href = loginData.login_url + '?username='+ loginInfo.token + '&password=' + loginInfo.token + '&url=' + encodeURIComponent(encodeURIComponent(successUrl));
            break;

        case 'mikrotik':
            window.location.href = loginData.login_url + '/login?username='+ loginInfo.token + '&password=' + loginInfo.token + '&var=' + encodeURIComponent(successUrl);
            break;

        case 'meraki':
            var postData = {
                password: loginInfo.token,
                username: loginInfo.token,
                success_url: successUrl,
            };
            formPost(loginData.login_url, postData);
            break;

        case 'ignitenet':

        case 'coovachilli':

        case 'mojo':

            var loginUrl = loginData.login_url.split("?")[0];
            var extraParams = getUrlParams(loginData.login_url.split("?")[1]);

            console.log('------------ Mon loginInfo dans la fonction deviceLogin() -------------- ');
            console.log(loginInfo);

            var postData = {
                "password": loginInfo.token,
                "username": loginInfo.token,
                "url": encodeURIComponent(successUrl),
                "challenge" : extraParams.challenge,
                "uamip" : extraParams.uamip,
                "uamport" : extraParams.uamport
            };
            console.log('------------ Mon postData dans la fonction deviceLogin() -------------- ');
            console.log(postData);
            formPost(loginUrl, postData);

            break;

        case 'cambium':
            var loginUrl = loginData.login_url.split("?")[0];
            var extraParams = getUrlParams(loginData.login_url.split("?")[1]);
            extraParams.ga_orig_url = successUrl;
            var postData = {
                ga_user: loginInfo.token,
                ga_pass: loginInfo.token //,...extraParams
            };
            formPost(loginUrl, postData);
            break;

        case 'lancom':

        case 'ruckus': //vsz
            var postData = {
                username: loginInfo.token,
                password: loginInfo.token
            }
            request('post', loginData.login_url, postData).then((response) => {
                if (response.result.success) {
            // show success login message
        } else {
            // show error message
            console.log(response.result.error);
        }
    });
    break;

    default:
        console.log('unsupported device type');

    }
}

function buildSuccessURL() {
    // default success url is back to portal with success = You are now online
    // change here if you would like it to redirect to other url
    //return window.location.href.replace(window.location.search, '') + '?token=' + urlParams.token + '&apiUrl=' + urlParams.apiUrl + '/&success=You are now online';
    return window.location.href.replace(window.location.search, '') + 'landing.html?token=' + urlParams.token + '&apiUrl=' + urlParams.apiUrl+'&httpOnly=1';
}

function formPost(loginUrl, params) {
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", loginUrl);

    //Exple de Contenu de la variable params lorsque c'est une borne en Coova(NBOX) voir le case:'mojo' de la fonction deviceLogin() ci-dessus.
    /*
            var postData = {
            "password": loginInfo.token,
            "username": loginInfo.token,
            "url": encodeURIComponent(successUrl),
            "challenge" : extraParams.challenge,
            "uamip" : extraParams.uamip,
            "uamport" : extraParams.uamport
        };
    */

    for (var key in params) {
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden");
        hiddenField.setAttribute("name", key);
        hiddenField.setAttribute("value", params[key]);
        form.appendChild(hiddenField);
    }

    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}

function request(method, path, params) {
    return new Promise((resolve, reject) => {
        const httpRequest = new XMLHttpRequest();
    if (!httpRequest) {
        const error = 'XMLHttpRequest does not exist on your browser..';
        bus.emit(APP_EVENTS.toast, new ToastEvent(error));
        reject(error);
        return;
    }
    httpRequest.onreadystatechange = () => requestCallback(httpRequest, resolve, reject);

    path += queryParams(method, params);
    let body = undefined;
    httpRequest.open(method, path);
    httpRequest.setRequestHeader("Content-type", "application/json");
    if (method !== 'get') {
        body = JSON.stringify(params);//JSON.parse();
    }
    httpRequest.send(body);
});
}

function queryParams(method, params) {
    if (method !== 'get') {
        return '';
    }
    return '?' + Object.keys(params)
        .map(k => encodeURIComponent(k) + '=' + encodeURIComponent(params[k]))
.join('&');
}

function requestCallback(httpRequest, resolve, reject) {
    if (httpRequest.readyState === XMLHttpRequest.DONE) {
        try {
            if (httpRequest.status === 200) {
                const response = JSON.parse(httpRequest.responseText);
                return resolve(response);
            } else {
                const response = JSON.parse(httpRequest.responseText);
                return reject(response.error);
            }
        } catch (e) {
            const error = 'Error parsing json: ' + httpRequest.responseText;
            return reject(error);
        }
    }
}

function getUrlParams(searchString) {
    const result = {};
    if (searchString === '') {
        return result;
    }
    searchString.split('&').forEach((part) => {
        const item = part.split('=');
    result[item[0]] = decodeURIComponent(item[1]);
});
    return result;
}

// request to /hotspot/details endpoint to get hotspot information
const urlParams = getUrlParams(window.location.search.substr(1));
const path = urlParams.apiUrl + "/details";
const error = urlParams.error;
const params = { "user_token" : urlParams.token };

var  pathHotspotDetail = path, paramshotspotDetail = params;

var loginInfo, surveyId, hotspotDetail, redirectUrl = '';//http://www.nice.fr/fr/';

request("get", path, params).then((response) => {

    loginInfo = response.result.nas;
    hotspotDetail = response.result;
    console.log(' -------- Les infos sur le resultat après ma requête https://sphere.nomosphere.fr/papi/hotspot/details ==> Contenu de hotspotDetail(esponse.result) : ------ ');
    console.log(hotspotDetail);

    console.log(' -------- Les infos sur le resultat après ma requête https://sphere.nomosphere.fr/papi/hotspot/details ==> Partie NAS, Contenu de loginInfo(result.nas) : ------ ');
    console.log(loginInfo);

     surveyId = response.result.surveys[0].id;//

    //On envoie ensuite une requete pour poster chez Encapto les infos sur le device du User
    var pathPostUserInfos = urlParams.apiUrl + "/user-info";
    var screen_orientation = 'landscape';
    if (window.screen.height > window.screen.width) {
        screen_orientation = 'portrait';
    }

    var userDeviceDatasInfos = {
        "user_token": urlParams.token,
        "user_agent": window.navigator.userAgent,
        "device_width": document.body.offsetWidth,
        "device_height": document.body.offsetHeight,
        "screen_width": window.screen.width,
        "screen_height": window.screen.height,
        "screen_orientation": screen_orientation,
        "is_retina": (window.devicePixelRatio > 1)
    };

request("post", pathPostUserInfos, userDeviceDatasInfos).then((response) => {
    var deviceDatasUsersInfos = response;
console.log(' -------- Les infos du device du User envoyé à Encapto ------ ');
console.log(userDeviceDatasInfos);

console.log(' -------- Les infos sur le resultat après ma requête de POST (/hotspot/user-info) ==> Contenu de loginData : ------ ');
console.log(deviceDatasUsersInfos);

}).catch((response) => {
    console.log('Erreur lors de l\'envoie du User Device Infos (/hotspot/user-info) ',response);
});

//   ------------   Fin de ma requete pour envoyer les infos du Device utilisateur   ----------- //

    for (var i in response.result.auths) {

        var auth = response.result.auths[i];

        //Si le type de connexion est 'click' alors on
        if( auth.type === 'click' )
        {
            //Recupération de mon formulaire de connexion
            var connexionForm = document.getElementById("idSubmitConnectForm");

            //Lorsqu'on clique sur le bouton de soumission de mon formulaire
            connexionForm.onsubmit = ((e) => {
                console.log(' -------- jai soumis le formulaire  : ------ ');
            console.log(' -------- Les infos sur le détail de mon hotspot : ------ ');
            console.log(response.result);

            //-------------  Debut d'envoie des données de sondage -----------------------

            //J'envoie la requête avec mes données de sondage
            var pathUrlSurvey = urlParams.apiUrl +"/surveys";
            //curl -X POST "https://sphere.nomosphere.fr/papi/hotspot/surveys" -H "accept: application/json"
            // -d "survey_id=6&auth_id=30&answers= [question= 'Ton Email'&answer=rkouam@yahoo.fr], \"user_token\": \"78828927-163a-42bf-a3ac-6e0ef7031a4e\" }"
            var optinSurvey = (document.getElementById("declarative_logon_tos").checked == true ) ? true : false;
            var pays = document.getElementById("declarative_logon_countryCode");
            var paysPrefixe = pays.value;
            var paysLib = pays.options[pays.selectedIndex].text;
            var dataSurvey = {
                "survey_id" : surveyId,
                "auth_id": auth.id,
                "answers": new Array( {"question":"E-mail", "answer": document.getElementById("declarative_logon_email").value},
                    {"question":"Optin", "answer": optinSurvey},
                    {"question":"Pays", "answer": paysPrefixe+' - '+paysLib }
                ),
                "user_token": urlParams.token
            };

            console.log(' -------- Les infos envoyées dans ma requête de Sondage(/papi/hotspot/surveys) ==> Contenu de dataSurvey : ------ ');
            console.log(dataSurvey);

            request("post", pathUrlSurvey, dataSurvey).then((response) => {

                console.log(' -------- Les infos sur le resultat après ma requête de Sondage(/papi/hotspot/surveys) ==> Contenu de response.result : ------ ');
            console.log(response.result);

            if( response.error !== null ) { return false; }

        }).catch((response) => {
            console.log(response);
        });

            //-------------------   Fin d'envoie des données de sondage ----------------------------------


            var loginData;//https://sphere.nomosphere.fr/api/hotspot
            var path = urlParams.apiUrl + "/auths/" + auth.id + "/click";

            //J'envoie la requête mon mode d'authentification avec en paramètre mon user_token
            request("post", path, {"user_token": urlParams.token}).then((response) => {
                loginData = response.result;

            console.log(' -------- Les infos sur le resultat après ma requête de click(/auths/auth.id/click) ==> Contenu de loginData : ------ ');
            console.log(loginData);

            //J'appelle ma fonction qui a pour but de simuler un formulaire et de le soumettre avec les données qui proviennent
            //de la reponse à la requête =>  var path = urlParams.apiUrl + "/auths/" + auth.id + "/click";
            deviceLogin(loginInfo, loginData, redirectUrl);

        }).catch((response) => {
            console.log(response);
        });

            return false;

        });

        }

    }

}).catch((response) => {
    console.log(response);
});

/* --------------  Fin de ma fonction JS pour modifier l'action de mon formulaire de connexion ---------   */
