$(".header-menu-mini-button").on("click", function(e) {
    e.stopPropagation();
    $(".header-menu-mini-container").toggle();
    $(".header-menu-mini-button").toggleClass('header-menu-mini-container-darker');
});

$("body").not(".header-menu-mini-container").not(".header-menu-mini-button").on("click", function() {
    if ($(".header-menu-mini-container").is(":visible")) {
        $(".header-menu-mini-container").hide();
        $(".header-menu-mini-button").removeClass('header-menu-mini-container-darker');
    }
});

$("#menu_button_destinations_fr, #menu_mini_button_destinations_fr").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/destinations");
});
$("#menu_button_destinations_en, #menu_mini_button_destinations_en").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/en/destinations");
});

$("#menu_button_parking_fr, #menu_mini_button_parking_fr").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/acces");
});
$("#menu_button_parking_en, #menu_button_parking_en").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/en/access");
});

$("#menu_button_services_fr, #menu_mini_button_services_fr").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/services");
});
$("#menu_button_services_en, #menu_mini_button_services_en").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/en/services");
});

$("#menu_button_discover_fr, #menu_mini_button_discover_fr").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/region");
});
$("#menu_button_discover_en, #menu_mini_button_discover_en").on("click", function() {
    window.location.assign("http://www.toulon-hyeres.aeroport.fr/en/region");
});