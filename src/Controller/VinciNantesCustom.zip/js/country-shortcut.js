$('div.country_shortcut_selector').on('click', function(e) {
    e.preventDefault();
    var value = $(this).attr('data-shortcut-value');
    $('select#declarative_logon_countryCode').val(value);
});